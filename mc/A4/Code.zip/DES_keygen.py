import operator
import numpy as np

Inv_Permutation_Box = [9, 17, 23, 31, 13, 28, 2, 18, 24, 16, 30, 6, 26, 20, 10, 1, 8, 14, 25, 3, 4, 29, 11, 19, 32, 12,
                       22, 7, 5, 27, 15, 21]

dct = {'u': [1, 1, 1, 1], 'f': [0, 0, 0, 0], 't': [1, 1, 1, 0], 's': [1, 1, 0, 1], 'r': [1, 1, 0, 0], 'q': [1, 0, 1, 1], 'n': [1, 0, 0, 0], 'p': [1, 0, 1, 0],
       'o': [1, 0, 0, 1], 'i': [0, 0, 1, 1], 'h': [0, 0, 1, 0],  'k': [0, 1, 0, 1],
        'm': [0, 1, 1, 1], 'l': [0, 1, 1, 0], 'j': [0, 1, 0, 0],
       'g': [0, 0, 0, 1]}

Inverse_Final_Permutation = [57,49,41,33,25,17,9,1,59,51,43,35,27,19,11,3,61,53,45,37,29,21,13,5,63,55,47,39,31,23,15,7,58,50,42,34,26,18,10,2,60,52,44,36,28,20,12,4,62,54,46,38,30,22,14,6,64,56,48,40,32,24,16,8]

S_Box = [[[14, 4, 13, 1, 2, 15, 11, 8, 3 , 10, 6, 12, 5, 9, 0, 7],
    [0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8],
    [4, 1 , 14, 8, 13, 6, 2, 11, 15, 12, 9, 7,3, 10, 5, 0],
    [15, 12, 8,2,4, 9, 1,7 , 5, 11, 3, 14, 10, 0, 6, 13]],

    [[15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0,5, 10],
    [3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5],
    [0, 14, 7, 11, 10, 4, 13, 1, 5, 8,12, 6, 9, 3, 2, 15],
    [13, 8, 10, 1, 3, 15, 4, 2,11,6, 7, 12, 0,5, 14, 9]],

    [[10, 0, 9,14,6,3,15,5, 1, 13, 12, 7, 11, 4,2,8],
    [13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1],
    [13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12,5, 10, 14, 7],
    [1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12]],

    [[7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15],
    [13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9],
    [10, 6, 9, 0, 12, 11, 7, 13, 15, 1 , 3, 14, 5, 2, 8, 4],
    [3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14]],

    [[2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9],
    [14, 11,2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6],
    [4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14],
    [11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3]],

    [[12, 1, 10, 15, 9, 2, 6,8, 0, 13, 3, 4, 14, 7, 5, 11],
    [10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8],
    [9, 14, 15, 5, 2,8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6],
    [4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13]],

    [[4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1],
    [13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6],
    [1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2],
    [6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12]],

    [[13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12,7],
    [1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2],
    [7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8],
    [2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11]]]

Exp_Box = [32, 1, 2, 3, 4, 5, 4, 5, 6, 7, 8, 9, 8, 9, 10, 11, 12, 13, 12, 13, 14, 15, 16, 17, 16, 17, 18, 19, 20, 21,
           20, 21, 22, 23, 24, 25, 24, 25, 26, 27, 28, 29, 28, 29, 30, 31, 32, 1]


def fun():
    pass

def write():
    pass

def write1():
    pass

def read():
    pass


conc_inputs = []
X_inp = []
X_S_In = []
Fiest_Out = []
X_S_Out = []
index = []
inp = []
average = []
max_key = []
keys = []
vals = {}
keys_bin = []
Expanded_LOut = []

temp_arr = open("cleaned_output.txt")

dat = temp_arr.read().split("\n")

"""i = 0
j = 0
while i < (len(dat)-1):
    if (len(dat[i]) != 16):
        print (i)

    tmp = []
    while j < 16:
        tmp = tmp+dct[dat[i][j]]
        j = j + 1


    i = i + 1
    inp.append(tmp)"""

for i in range(len(dat) - 1):
    if (len(dat[i]) == 16):
        pass
    else:
        print(i)

    #Using a nested for loop
    tmp = []
    for j in range(16):
        tmp = tmp + dct[dat[i][j]]
    inp.append(tmp)

print("\n")
# Print statement to create spaces

for j in range(len(inp)):
    # Using a nested for loop
    temp = []
    for i in range(64):
        temp.append(inp[j][Inverse_Final_Permutation[i] - 1])

    conc_inputs.append(temp)

print("\n")
# Print statement to create spaces

# XOR of Inverse Permuted Input


for i in range(len(inp)//2):
    X_inp.append(list(np.bitwise_xor(conc_inputs[2*i+1],conc_inputs[2*i])))


fun()

# Expanding R5 = L6 to get Alphas
#Alpha = Expanded_Lout


for j in range(len(inp)):
    # Using a nested for loop
    temp = []
    for i in range(48):
        temp.append(conc_inputs[j][Exp_Box[i] - 1])

    Expanded_LOut.append(temp)

write()
# Calculating XOR of Alphas Or Input To S-Boxes

for i in range(len(inp)//2):
    X_S_In.append(list(np.bitwise_xor(Expanded_LOut[2*i+1],Expanded_LOut[2*i])))

#X_S_In = [list(np.bitwise_xor(Expanded_LOut[2*i+1],Expanded_LOut[2*i])) for i in range(len(inp)//2)]

# Fiestal XORED Output, XOR of L5 and R6


a1 = [0,0,0,0,0,1]
a2 = [0]*26

L5 = a1 + a2

for i in range(len(X_inp)):
    Fiest_Out.append(list(np.bitwise_xor(X_inp[i][32:64],L5)))

#Fiest_Out = [list(np.bitwise_xor(X_inp[i][32:64],L5)) for i in range(len(X_inp))]

# Calculating the output XOR after S-Box

file = open("inp_diff.txt","w")
file1 = open("out_diff.txt","w")

write1()

for j in range(len(Fiest_Out)):
    temp = []
    for i in range(32):
        temp.append(Fiest_Out[j][Inv_Permutation_Box[i] - 1])

    X_S_Out.append(temp)


for i in X_S_In:

    if(False):
        break
    # using a nested loop
    st=""
    for j in i:
        #concatenating the string
        st=st+str(j)
        #writing in the file
    file.write(st)
    file.write("\n")
file.close()

write()

for i in X_S_Out:
    if (False):
        break
    # using a nested loop

    st=""
    for j in i:
        #concatenating the string
        st=st+str(j)
    #writing in the file
    file1.write(st)
    file1.write("\n")
file1.close()


write1()

file = open("out_exp.txt","w")

for i in range(len(Expanded_LOut)):
    if (False):
        break
    # using a nested loop
    if i%2==1:
        continue
    st=""
    for j in Expanded_LOut[i]:
        # concatenating the string
        st=st+str(j)
    # writing in the file
    file.write(st)
    file.write("\n")
file.close()


read()
read()

#print (L5)

LOut = open("out_exp.txt").read().split("\n")
X_S_Out = open("out_diff.txt").read().split("\n")
Keys = np.zeros((8,64))
X_S_In = open("inp_diff.txt").read().split("\n")



fun()

for i in range(len(X_S_In)):
    if X_S_In[i] == "":
        continue
    inpos = LOut[i]
    outxs = X_S_Out[i]
    inpxs = X_S_In[i]

    # LHS of the final output expanded
    for j in range(8):
        inp_orig = int(inpos[j * 6:j * 6 + 6], 2)
        outx = int(outxs[j * 4:j * 4 + 4], 2)
        inx = int(inpxs[j * 6:j * 6 + 6], 2)

        for k in range(64):

            a = k
            b = k ^ inx
            s = j
            b = '{:0>6}'.format(format(b, "b"))
            a = '{:0>6}'.format(format(a, "b"))
            c1 = int(a[4]) + 2 * int(a[3]) + int(a[2]) * 4 + int(a[1]) * 8
            r1 = int(a[0]) * 2 + int(a[5])

            c2 = int(b[4]) + 2 * int(b[3]) + int(b[2]) * 4 + int(b[1]) * 8
            r2 = int(b[0]) * 2 + int(b[5])

            if outx == (S_Box[s][r1][c1]) ^ (S_Box[s][r2][c2]):
                key_cand = k ^ inp_orig
                Keys[j][key_cand] = Keys[j][key_cand] + 1

# print (Keys)



for i in Keys:
    inde, value = max(enumerate(i), key=operator.itemgetter(1))
    index.append(inde)
    average.append(int(round(np.mean(i))))
    max_key.append(int(value))

"""print (index)
print (average)
print (max_key)"""


k = 0

key = [24, 27, 21, 6, 11, 15,
       13, 10, 25, 16, 3, 20,
       51, 34, 41, 47, 29, 37,
       40, 50, 33, 55, 43, 30,
       54, 31, 49, 38, 44, 35,
       56, 52, 32, 46, 39, 42]

for i in key:
    keys.append(i - 1)

i = 0
while i < len(key):
    keys.append(key[i] - 1)
    i = i + 1

Master_Key = [-1] * 56
# Master_Key = [-1 for i in range(56)]

marked = [0] * 56
# marked = [0 for i in range(56)]

for i in range(8):
    if i == 0 or i == 1 or i > 3:
        keys_bin.append('{:0>6}'.format(format(index[i], "b")))
        for j in range(6):
            vals[keys[k * 6 + j]] = int(keys_bin[k][j])
        k = k + 1

for i in range(56):
    if i in keys:
        marked[i] = 1
        Master_Key[i] = int(vals[i])

i = 0

while i < 56:
    if i in keys:
        Master_Key[i] = int(vals[i])
        marked[i] = 1

    i = i + 1
#print(Master_Key)


Final_Keys = []
for i in range(2**20):
    tmp = list('{:0>20}'.format(format(i,"b")))
    done = 0
    mkey = [Master_Key[j] for j in range(56)]
    for j in range(56):
        if Master_Key[j]==-1:
            mkey[j] = int(tmp[done])
            done=done+1
    Final_Keys.append(mkey)

#print (len(Final_Keys))

file = open("Keys.txt", "w")

i = 0
j = 0

def call():
    pass

call()

while i < (2 ** 20):
    if i % 1000000 == 0:
        print(i)

    tmp = list('{:0>20}'.format(format(i, "b")))
    done = 0
    mkey = [Master_Key[j] for j in range(56)]

    while j < 56:
        if Master_Key[j] == -1:
            mkey[j] = int(tmp[done])
            done = done + 1
        j = j + 1
    for zz in mkey:
        file.write(str(zz))
    file.write("\n")

    i = i + 1

file.close()

