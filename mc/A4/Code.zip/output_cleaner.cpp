#include <bits/stdc++.h>
using namespace std;
int main()
{
  int index = 0;
  char input[100],out[100];
  FILE *output,*output_clean;
  output = fopen("output1.txt","r+");
  output_clean = fopen("clean_output1.txt","w+");
  
  while(index < 40000)
  {
    strcpy(input,out);
    fscanf(output,"%s",input);
    if(strlen(input) == 16)
    {
        fprintf(output_clean, "%s\n",input);
        index++;
    }
  }
}
