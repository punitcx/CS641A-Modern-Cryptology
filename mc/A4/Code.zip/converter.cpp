#include<bits/stdc++.h>
using namespace std;

int main()
{
	string s="luomqnlfnkuuulitiulsqimkfqgsrmfp";
	
	int len=s.size();
	
	map<char, int> mp;
	
    	mp['f']=0; mp['g']=1; mp['h']=2; mp['i']=3; mp['j']=4; mp['k']=5; mp['l']=6; mp['m']=7; mp['n']=8; mp['o']=9; mp['p']=10; mp['q']=11; mp['r']=12; mp['s']=13; mp['t']=14; mp['u']=15;  
   

//cout<<mp[s[2]];	
	
	
	for(int i=0;i<len;i=i+2)
	{
		int k;
		k= (mp[s[i]]*16)+mp[s[i+1]];
		cout<<k<<" ";
	
	}
	cout<<endl;

}
