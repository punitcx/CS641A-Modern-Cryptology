#include <bits/stdc++.h>
time_t t;
using namespace std;
int main()
{
  char a[64];
  FILE *ran;
  ran = fopen("random.txt","w+");	
  long long int rand_no;
  
  for(j=0;j<100000;j++)
  {
  	int i =0;
    while(i<64)
    {
      rand_no = rand()%2;
      
      rand_no = rand_no + 48;
      a[i] = rand_no;
      i++;
    }
    
    for (int k = 0; k < 64; k++)
      fprintf(ran, "%c",a[k]);
      
    fprintf(ran, "\n");

  }

}
